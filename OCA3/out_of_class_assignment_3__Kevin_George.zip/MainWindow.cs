﻿/*
 * Name: Kevin George
 * Teac: Prof. Gordon
 * Clas: CST-135 900A
 * Date: Oct 10, 2018
 */

using System;
using System.IO;
using System.Threading;
using System.Collections.Generic;
using Gtk;

public partial class MainWindow : Gtk.Window
{
    
	public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        Build();
    }

    protected void OnDeleteEvent(object sender, DeleteEventArgs a)
    {
        Application.Quit();
        a.RetVal = true;
    }
    void lowerCase(string[] lc)
	{
		string eachWord = " ";
		string[] lowerArray = new string[lc.Length];
		for (int i = 0; i < lc.Length; i++)
		{
			eachWord = lc[i];
			eachWord = eachWord.ToLower();
			lowerArray[i] = eachWord;
			System.IO.File.WriteAllLines(@"/home/kevin/Kevin/school/CST117/workspace/OCA3/lowerCase.txt", lowerArray);
		}      
	}
	void alphabetically(string[] ab)
	{
		//string unorderedWord = " ";
		string[] sortArray = new string[ab.Length];
		Array.Sort(ab);
		for (int i = 0; i < ab.Length; i++)
		{
			sortArray[i] = ab[i];
		}
		System.IO.File.WriteAllLines(@"/home/kevin/Kevin/school/CST117/workspace/OCA3/alphabetically.txt", sortArray);
	}
	void longestWord(string[] lw)
	{
		string longWord = " ";
		string[] tooLong = new string[1];
		for (int i = 0; i < lw.Length; i++)
		{
			if(lw[i].Length > longWord.Length)
			{
				longWord = lw[i];
			}         
		}
		tooLong[0] = longWord;
        System.IO.File.WriteAllLines(@"/home/kevin/Kevin/school/CST117/workspace/OCA3/longestWordinFile.txt", tooLong);
		label3.Text = (longWord);
	}
	void moistVowels(string[] mv)
	{
		string theWord = " ";
		int vowCount = 0;
		string[] wordwMostVow = new string[1];
		var vowels = new HashSet<char> { 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' };
		for (int i = 0; i < mv.Length; i++)
		{
			if(mv[i].Length > theWord.Length)
            {
				theWord = mv[i];            
            }         
		}
		for (int j = 0; j < theWord.Length; j++)
        {
            if (vowels.Contains(theWord[j]))
            {
                vowCount++;
            }
        }
		wordwMostVow[0] = "The word with the most vowels is: " +"'"+ theWord +"'"+ " with " + vowCount.ToString() + " vowels";
		System.IO.File.WriteAllLines(@"/home/kevin/Kevin/school/CST117/workspace/OCA3/wordwMostVowels.txt", wordwMostVow);      
	}
	protected void OnButton4Clicked(object sender, EventArgs e)
	{
		string input = System.IO.File.ReadAllText(@"/home/kevin/Kevin/school/CST117/workspace/OCA3/text_test.txt");
		string[] strArray;
		strArray = input.Split(' ');
		lowerCase(strArray);
		alphabetically(strArray);
		longestWord(strArray);
		moistVowels(strArray);
	}
}
