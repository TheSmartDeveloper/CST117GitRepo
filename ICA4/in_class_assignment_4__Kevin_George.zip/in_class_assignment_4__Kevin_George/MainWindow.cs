﻿using System;
using Gtk;

public partial class MainWindow : Gtk.Window
{
    public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        Build();
    }

    protected void OnDeleteEvent(object sender, DeleteEventArgs a)
    {
        Application.Quit();
        a.RetVal = true;
    }

	protected void ConvertInput(object sender, EventArgs e)
	{
		//entry4, entry5, entry6, entry7, entry8
		string Input;
		Input = entry4.Text;
		int secondsIn = 0;
        bool checkInput = int.TryParse(Input, out secondsIn);
		if (checkInput == true && secondsIn >= 0)
        {
            int days = 0;
            int hours = 0;
            int minutes = 0;
            int seconds = 0;

            int oneDayinSeconds = 86400;
            int oneHourinSeconds = 3600;
            int oneMinuteinSeconds = 60;

            if (secondsIn >= oneDayinSeconds)
            {
                days = secondsIn / oneDayinSeconds;
                secondsIn = secondsIn % oneDayinSeconds;
				entry5.Text = (Convert.ToString(days));
            }
            else
            {
				entry5.Text = (Convert.ToString(days));
            }
            if (secondsIn >= oneHourinSeconds)
            {
                hours = secondsIn / oneHourinSeconds;
                secondsIn = secondsIn % oneHourinSeconds;
				entry6.Text = (Convert.ToString(hours));
            }
            else
            {
				entry6.Text = (Convert.ToString(hours));
            }
            if (secondsIn >= oneMinuteinSeconds)
            {
                minutes = secondsIn / oneMinuteinSeconds;
                secondsIn = secondsIn % oneMinuteinSeconds;
				entry7.Text = (Convert.ToString(minutes));
            }
            else
            {
				entry7.Text = (Convert.ToString(minutes));
            }
            if (secondsIn < oneMinuteinSeconds)
            {
                seconds = secondsIn;
				entry8.Text = (Convert.ToString(seconds));
            }
            else
            {
				entry8.Text = (Convert.ToString(seconds));
            }

        }
		else
		{
			entry5.Text = ("Please");
            entry6.Text = ("use");
            entry7.Text = ("positive");
            entry8.Text = ("integers");
		}
	}
}
